module load cp2k && mpirun -n 2 cp2k.popt -i input.inp
